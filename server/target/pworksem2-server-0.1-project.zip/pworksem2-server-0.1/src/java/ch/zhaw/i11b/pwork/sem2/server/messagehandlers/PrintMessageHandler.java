package ch.zhaw.i11b.pwork.sem2.server.messagehandlers;

import ch.zhaw.i11b.pwork.sem2.beans.Message;

public class PrintMessageHandler extends AbstractMessageHandler {

	public PrintMessageHandler(String target, Message message) {
		super(target, message);
		// TODO Auto-generated constructor stub
	}

	public boolean send() {
		// TODO Auto-generated method stub
		return false;
	}

}

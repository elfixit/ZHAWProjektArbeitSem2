package ch.zhaw.i11b.pwork.sem2.server.messagehandlers;

public interface IMessageHandler {
	public boolean send();

}
